<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Explore The World</title>
<link rel="stylesheet" href="css/NorthAmerica.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<style>
    img:hover {
        opacity: 0.7; /* 设置悬停时的透明度 */
        transition: opacity 0.3s ease-in-out; /* 平滑的过渡效果 */
    }
</style>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        // 获取所有图片元素
        var images = document.querySelectorAll('img');
        images.forEach(function(img) {
            img.addEventListener('mouseover', function() {
                img.style.opacity = '0.7';
            });
            img.addEventListener('mouseout', function() {
                img.style.opacity = '1.0';
            });
        });
    });
</script>
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="lst.php">Home</a></li>
                <li><a href="blog.html">Forum</a></li>                  
            </ul>
            <div class="user-icon">
                <a href="edit.php"><i class="fas fa-user"></i></a>
            </div>
        </nav>
    </header>
    <section class="intro">
        <h1>Explore The World</h1>
        <p>Discover different regions and learn about their cultures.</p>
    </section>
    
 <div class="HoneymoonDesti">
            <div class="container">
                <div class="row">

                    <div>

                            <h1>Europe Tourism</h1>
                            <p>Europe is a premier destination, renowned for its rich history and diverse cultures, 
                            offering travelers from ancient ruins in Rome to modern art in Paris. The continent provides 
                            endless opportunities for exploration, from stunning landscapes to world-class cuisine.</p>
							
					
                    </div>
                    
                    <div class="container">
  <div class="row">
    <div class="col">
      <div class="row">
        <div class="col-sm-3">
          <h3>Eiffel Tower</h3>
          <a href="Rating.html"><img src="images/Paris.jpeg" alt="Image 1"></a>
          <span>Paris International customized tour package</span><hr>
          <span>MOP 30,000</span>
        </div>
        <div class="col-sm-3">
          <h3>Big Ben</h3>
          <a href="Rating.html"><img src="images/London.jpeg" alt="Image 1"></a>
          <span>London City International customized tour package</span><hr>
          <span>MOP 30,000</span>
        </div>
        <div class="col-sm-3">
          <h3>Sagrada Família</h3>
          <a href="Rating.html"><img src="images/Barcelona.jpeg" alt="Image 1"></a>
          <span>Barcelona International customized tour package</span><hr>
          <span>MOP 29,000</span>
        </div>
        <div class="col-sm-3">
          <h3>Amsterdam Canals</h3>
          <a href="Rating.html"><img src="images/Amsterdam.jpeg" alt="Image 1"></a>
          <span>Amsterdam City International customized tour package</span><hr>
          <span>MOP 24,000</span>
        </div>
      </div>
    </div>
  </div>
</div>


                    
                    </div>
                   </div>
                   </div>
                 <footer class="footer">
  <div class="footer-left">
            <a href="https://www.visa.com" target="_blank" class="visa-link">
                <img src="images/lstfooter.png" alt="Visa Payment" class="footer-logo">
                <span>Pay method</span>
            </a >
        </div>
        <div class="footer-middle">
       <p>    Discover the world with Explorer's Path, your ultimate travel companion! At Explorer's Path, we believe every journey should be unforgettable and hassle-free. Our website offers detailed guides, user-friendly tools, and insider tips to help you plan the perfect getaway. Whether you're dreaming of a serene beach vacation, an adventurous mountain trek, or a culturally rich city tour, Explorer's Path has everything you need to turn those dreams into reality.
</p>

        </div>
        <div class="footer-right">
            <p>©2024 Team 05 All rights reserved.</p>
        </div>
        
    </footer>
</body>
</html>