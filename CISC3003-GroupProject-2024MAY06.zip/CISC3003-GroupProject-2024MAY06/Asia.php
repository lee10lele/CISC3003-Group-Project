<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Explore The World</title>
<link rel="stylesheet" href="css/NorthAmerica.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<style>
    img:hover {
        opacity: 0.7; /* 设置悬停时的透明度 */
        transition: opacity 0.3s ease-in-out; /* 平滑的过渡效果 */
    }
</style>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        // 获取所有图片元素
        var images = document.querySelectorAll('img');
        images.forEach(function(img) {
            img.addEventListener('mouseover', function() {
                img.style.opacity = '0.7';
            });
            img.addEventListener('mouseout', function() {
                img.style.opacity = '1.0';
            });
        });
    });
</script>
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="lst.php">Home</a></li>
                <li><a href="blog.html">Forum</a></li>                  
            </ul>
            <div class="user-icon">
                <a href="edit.php"><i class="fas fa-user"></i></a>
            </div>
        </nav>
    </header>
    <section class="intro">
        <h1>Explore The World</h1>
        <p>Discover different regions and learn about their cultures.</p>
    </section>
    
<div class="HoneymoonDesti">
            <div class="container">
                <div class="row">

                    <div>

                            <h1>Asia Tourism</h1>
                            <p>Asia is a diverse continent that offers travelers 
                            a rich tapestry of cultures, historical sites, and breathtaking 
                            landscapes. From the bustling streets of Tokyo to the tranquil temples
                             of Bali, each destination provides a unique and unforgettable experience.</p>
							
					
                    </div>
                    
                    <div class="container">
  <div class="row">
    <div class="col">
      <div class="row">
        <div class="col-sm-3">
          <h3>Great wall</h3>
          <a href="Rating.html"><img src="images/Beijing.jpeg" alt="Image 1"></a>
          <span>Beijing International customized tour package</span><hr>
          <span>MOP 18,000</span>
        </div>
        <div class="col-sm-3">
          <h3>Bali</h3>
          <a href="Rating.html"><img src="images/Bali.jpeg" alt="Image 1"></a>
          <span>Bali City International customized tour package</span><hr>
          <span>MOP 17,000</span>
        </div>
        <div class="col-sm-3">
          <h3>Kyoto Temples</h3>
          <a href="Rating.html"><img src="images/Temples and Shrines of Kyoto.jpeg" alt="Image 1"></a>
          <span>Tokyo City International customized tour package</span><hr>
          <span>MOP 15,000</span>
        </div>
        <div class="col-sm-3">
          <h3>Taj Mahal</h3>
          <a href="Rating.html"><img src="images/Agra.jpeg" alt="Image 1"></a>
          <span>Agra International customized tour package</span><hr>
          <span>MOP 19,000</span>
        </div>
      </div>
    </div>
  </div>
</div>


                    
                    </div>
                   </div>
                   </div>
                 
<footer class="footer">
  <div class="footer-left">
            <a href="https://www.visa.com" target="_blank" class="visa-link">
                <img src="images/lstfooter.png" alt="Visa Payment" class="footer-logo">
                <span>Pay method</span>
            </a >
        </div>
        <div class="footer-middle">
       <p>    Discover the world with Explorer's Path, your ultimate travel companion! At Explorer's Path, we believe every journey should be unforgettable and hassle-free. Our website offers detailed guides, user-friendly tools, and insider tips to help you plan the perfect getaway. Whether you're dreaming of a serene beach vacation, an adventurous mountain trek, or a culturally rich city tour, Explorer's Path has everything you need to turn those dreams into reality.
</p>

        </div>
        <div class="footer-right">
            <p>©2024 Team 05 All rights reserved.</p>
        </div>
        
    </footer>
</body>
</html>