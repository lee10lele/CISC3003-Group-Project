<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/register.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Forgot Password</title>

    <script>
        function validateEmail() {
            var email = document.getElementById("email").value;
            var emailRegex = /^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/;
            if (!emailRegex.test(email)) {
                alert("Invalid email format. Please enter a valid email address.");
                return false;
            }
            return true;
        }
        
        function generateVerificationCode() {
            return Math.floor(1000 + Math.random() * 9000).toString();
        }
        
        function sendVerificationCode() {
            var email = document.getElementById("email").value;
            var verificationCode = generateVerificationCode();

            // Send the verification code to the email address
            var xhr = new XMLHttpRequest();
            var url = "send_verification_code.php";
            var params = "email=" + email + "&verificationCode=" + verificationCode;
            xhr.open("POST", url, true);
            xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                alert(xhr.responseText);
            }
            };
        xhr.send(params);
        }
    </script>


</head>
<body>
    <div class="wrapper">
    <nav class="nav">
        <div class="nav-logo">
            <p>Traveling Website</p>
        </div>
        <div class="nav-menu" id="navMenu">
            <ul>
                <li><a href="#" class="link active">Home</a></li>
                <li><a href="#" class="link">Blog</a></li>
                <li><a href="#" class="link">Services</a></li>
                <li><a href="#" class="link">About</a></li>
            </ul>
        </div>
        <div class="nav-button">
            <button class="btn white-btn" id="loginBtn" onclick="login()">Sign In</button>
            <button class="btn" id="registerBtn" onclick="register()">Sign Up</button>
        </div>
        <div class="nav-menu-btn">
            <i class="bx bx-menu" onclick="myMenuFunction()"></i>
        </div>
    </nav>

        <div class="form-box">
            <div class="login-container" id="forgot-password">

<?php
        include("php/config.php");

    if (isset($_POST['submit'])) {
        
        $email = mysqli_real_escape_string($con, $_POST['email']);

        // Check if the email exists in the database
        $result = mysqli_query($con, "SELECT * FROM users WHERE Email='$email'") or die("Select Error");
        $row = mysqli_fetch_assoc($result);

        
    } elseif (isset($_POST['submit'])) {
        $email = $_SESSION['reset_email'];
        $password = mysqli_real_escape_string($con, $_POST['password']);
        $repeatPassword = mysqli_real_escape_string($con, $_POST['repeat_password']);
        $verificationCode = $_POST['verificationCode'];

        // Check if passwords match
        if ($password !== $repeatPassword) {
            echo "Passwords do not match. Please try again.";
            exit();
        }

        // Check if verification code is correct
        if (isset($_SESSION['verificationCode']) && $verificationCode != $_SESSION['verificationCode']) {
            echo "Incorrect verification code. Please try again.";
            exit();
        }

        // Update the password
        $edit_query = mysqli_query($con, "UPDATE users SET Password='$password' WHERE Email='$email'") or die("Error occurred");

        if ($edit_query) {
            echo "Password Updated!";
            // Redirect to login page or any other page you prefer
            // header("Location: login.php");
            // exit();
        }
    }else {

?>
                <header>Forgot Password</header>
                <form action="forgot_password.php" method="post" onsubmit="return validateEmail()">
                    <div class="input-box">
                        <input type="email" class="input-field" placeholder="Enter your email" name="email" autocomplete="off" required>
                        <i class="bx bx-envelope"></i>
                        <button type="button" class="email-button" onclick="sendVerificationCode()">Send Code</button>
                    </div>

                    
                    <div class="input-box">
                        <input type="password" class="input-field" placeholder="Password" name="password" id="password" autocomplete="off" required>
                        <i class="bx bx-lock-alt"></i>
                    </div>
                    <div class="input-box">
                        <input type="password" class="input-field" placeholder="Repeat Your Password" name="repeat_password" id="repeat_password" autocomplete="off" required>
                        <i class="bx bx-lock-alt"></i>
                    </div>
                    <div class="input-box">
                        <input type="text" class="input-field" placeholder="Verification Code" name="verificationCode" id="verificationCode" autocomplete="off" required>
                        <i class="bx bx-key"></i>
                    </div>
                    <div class="input-box">
                    <input type="submit" class="submit" name="submit" value="Register" required>

                    </div>
                </form>
            </div>
        </div>
        <?php } ?>
    </div>
</body>
</html>
