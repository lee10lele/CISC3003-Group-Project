<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<link rel="stylesheet" href="css/NorthAmerica.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="lst.php">Home</a></li>
                <li><a href="blog.html">Forum</a></li>                  
            </ul>
            <div class="user-icon">
                <a href="edit.php"><i class="fas fa-user"></i></a>
            </div>
        </nav>
    </header>
     <section class="intro">
        <h1>Explore The World</h1>
        <p>Discover different regions and learn about their cultures.</p >
    </section>
    
   <div class="HoneymoonDesti">
            <div class="container">
                <div class="row">

                    <div>

                            <h1>North America Tourism</h1>
                            <p>North America is the third largest continent in the world, home to some of the most amazing natural wonders and modern cities. With an estimated population of 380 million people, there are hundreds of cultures and sights for you to soak in. From pristine lakes to urban cityscapes, tall mountains to white sand beaches, you can be sure your North America tours will be unlike any other.</p>
							
					
                    </div>
                    
                    <div class="container">
  <div class="row">
    <div class="col">
      <div class="row">
        <div class="col-sm-3">
          <h3>Manhattan</h3>
          <a href="Rating.html"><img src="images/NY.png" alt="Image 1"></a>
          <span>New York International customized tour package</span><hr>
          <span>MOP 23,000</span>
        </div>
        <div class="col-sm-3">
          <h3>CN Tower</h3>
          <a href="Rating.html"><img src="images/canada.jpeg" alt="Image 1"></a>
          <span>Toronto City International customized tour package</span><hr>
          <span>MOP 23,000</span>
        </div>
        <div class="col-sm-3">
          <h3>Guanajuato</h3>
          <a href="Rating.html"><img src="images/Mexico.jpeg" alt="Image 1"></a>
          <span>Mexico City International customized tour package</span><hr>
          <span>MOP 23,000</span>
        </div>
        <div class="col-sm-3">
          <h3>ND Basilica</h3>
          <a href="Rating.html"><img src="images/Montreal.jpeg" alt="Image 1"></a>
          <span>Montreal City International customized tour package</span><hr>
          <span>MOP 23,000</span>
        </div>
      </div>
    </div>
  </div>
</div>


                    
                    </div>
                   </div>
                   </div>
                   <footer class="footer">
  <div class="footer-left">
            <a href="https://www.visa.com" target="_blank" class="visa-link">
                <img src="images/lstfooter.png" alt="Visa Payment" class="footer-logo">
                <span>Pay method</span>
            </a >
        </div>
        <div class="footer-middle">
       <p>    Discover the world with Explorer's Path, your ultimate travel companion! At Explorer's Path, we believe every journey should be unforgettable and hassle-free. Our website offers detailed guides, user-friendly tools, and insider tips to help you plan the perfect getaway. Whether you're dreaming of a serene beach vacation, an adventurous mountain trek, or a culturally rich city tour, Explorer's Path has everything you need to turn those dreams into reality.
</p>

        </div>
        <div class="footer-right">
            <p>©2024 Team 05 All rights reserved.</p>
        </div>
        
    </footer>

</body>
</html>