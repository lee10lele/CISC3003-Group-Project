<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/register.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Register</title>

    <script>
        function validateEmail() {
            var email = document.getElementById("email").value;
            var emailRegex = /^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/;
            if (!emailRegex.test(email)) {
                alert("Invalid email format. Please enter a valid email address.");
                return false;
            }
            return true;
        }
        
        function generateVerificationCode() {
            return Math.floor(1000 + Math.random() * 9000).toString();
        }
        
        function sendVerificationCode() {
            var email = document.getElementById("email").value;
            var verificationCode = generateVerificationCode();

            // Send the verification code to the email address
            var xhr = new XMLHttpRequest();
            var url = "send_verification_code.php";
            var params = "email=" + email + "&verificationCode=" + verificationCode;
            xhr.open("POST", url, true);
            xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                alert(xhr.responseText);
            }
            };
        xhr.send(params);
        }
    </script>

</head>
<body>
<div class="wrapper">
<nav class="nav">
            <div class="nav-logo">
                <p>Traveling Website</p>
            </div>
            <div class="nav-menu" id="navMenu">
                <ul>
                    <li><a href="#" class="link active">Home</a></li>
                    <li><a href="#" class="link">Blog</a></li>
                    <li><a href="#" class="link">Services</a></li>
                    <li><a href="#" class="link">About</a></li>
                </ul>
            </div>
        </nav>
<div class="form-box">
        
        <!------------------- registration form -------------------------->
        <div class="register-container" id="register">

        <?php 
         
         include("php/config.php");
         if(isset($_POST['submit'])){
            $username = $_POST['username'];
            $email = $_POST['email'];
            $age = $_POST['age'];
            $password = $_POST['password'];
            $verificationCode = $_POST['verificationCode'];

         //verifying the unique email

         $verify_query = mysqli_query($con,"SELECT Email FROM users WHERE Email='$email'");

         if(mysqli_num_rows($verify_query) !=0 ){
            echo "<div class='message'>
                      <p>This email is used, Try another One Please!</p>
                  </div> <br>";
            echo "<a href='javascript:self.history.back()'><button class='btn'>Go Back</button>";
         }
         else{
            session_start();
            // Check if the stored verification code matches the submitted one
            if (isset($_SESSION['verificationCode']) && $verificationCode === $_SESSION['verificationCode']) {
                // Check if the email is already registered
                $verify_query = mysqli_query($con, "SELECT Email FROM users WHERE Email='$email'");
                if (mysqli_num_rows($verify_query) != 0) {
                    echo "<div class='message'>
                              <p>This email is already in use. Please try another one.</p>
                          </div> <br>";
                    echo "<a href='javascript:self.history.back()'><button class='btn'>Go Back</button>";
                } else {
                    // Insert the user into the database
                    mysqli_query($con, "INSERT INTO users(Username,Email,Age,Password) VALUES('$username','$email','$age','$password')") or die("Error Occurred");
                    echo "<div class='message'>
                              <p>Registration successful!</p>
                          </div>";
                    echo "<a href='index.php'><button class='btn'>Login Now</button>";
                    session_destroy();
                }
            } else {
                echo "<div class='message'>
                          <p>Invalid verification code. Please enter a valid code.</p>
                      </div>";
                echo "<a href='javascript:self.history.back()'><button class='btn'>Go Back</button>";
            }
        }
    } else {
    ?>
            <div class="top">
                <span>Have an account? <a href="index.php">Login</a></span>
                <header>Sign Up</header>
            </div>
            <form action="" method="post" onsubmit="return validateEmail()">
            <div class="input-box">
                <input type="text" class="input-field" placeholder="Username" name="username" id="username" autocomplete="off" required>
                <i class="bx bx-user"></i>
            </div>

            <div class="input-box">
                <input type="text" class="input-field" placeholder="Email" name="email" id="email" autocomplete="off" required>
                <i class="bx bx-envelope"></i>
                <button type="button" class="email-button" onclick="sendVerificationCode()">Send Code</button>
            </div>

            <div class="input-box">
                <input type="number" class="input-field" placeholder="Age" name="age" id="age" autocomplete="off" required>
                <i class="bx bx-calendar"></i>
            </div>
            <div class="input-box">
                <input type="password" class="input-field" placeholder="Password" name="password" id="password" autocomplete="off" required>
                <i class="bx bx-lock-alt"></i>
            </div>
            <div class="input-box">
                <input type="text" class="input-field" placeholder="Verification Code" name="verificationCode" id="verificationCode" autocomplete="off" required>
                <i class="bx bx-key"></i>
            </div>
            <div class="input-box">
                <input type="submit" class="submit" name="submit" value="Register" required>
            </div>
            
            </form>
        </div>
        <?php } ?>
      </div>
</body>
</html>