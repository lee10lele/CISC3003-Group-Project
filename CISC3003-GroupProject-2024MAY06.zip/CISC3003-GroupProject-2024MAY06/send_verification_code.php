<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

function generateVerificationCode()
{
    return strval(rand(1000, 9999));
}

function sendVerificationCode($email, $verificationCode)
{
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'xyz20021019@gmail.com'; // Replace with your sender email
    $mail->Password = 'aybvvadoegyswfah'; // Replace with your email password
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;

    $mail->setFrom('xyz20021019@gmail.com', 'xyz'); // Replace with your sender email and name
    $mail->addAddress($email);

    $mail->isHTML(true);
    $mail->Subject = 'Verification Code';
    $mail->Body = 'Your verification code is: ' . $verificationCode;

    if ($mail->send()) {
        echo 'Verification code has been sent to your email.';
    } else {
        echo 'Error while sending email: ' . $mail->ErrorInfo;
    }
}

$email = $_POST['email'];
$verificationCode = generateVerificationCode();

session_start();
$_SESSION['verificationCode'] = $verificationCode;

sendVerificationCode($email, $verificationCode);
?>