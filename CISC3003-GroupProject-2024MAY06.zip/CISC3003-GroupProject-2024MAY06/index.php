<?php 
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/login.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Login</title>
</head>
<body>
    <div class="wrapper">
        <nav class="nav">
            <div class="nav-logo">
                <p>Traveling Website</p>
            </div>
            <div class="nav-menu" id="navMenu">
                <ul>
                    <li><a href="#" class="link active">Home</a></li>
                    <li><a href="#" class="link">Blog</a></li>
                    <li><a href="#" class="link">Services</a></li>
                    <li><a href="#" class="link">About</a></li>
                </ul>
            </div>
        </nav>

        <div class="form-box">
            <div class="login-container" id="login">
                
                <div class="top">
                    <span>Don't have an account? <a href="register.php">Sign Up</a></span>
                </div>
                <header>Login</header>
                <form action="" method="post">
                    <div class="input-box">
                        <input type="text" class="input-field" placeholder="Username or Email" name="email" id="email" autocomplete="off" required>
                        <i class="bx bx-user"></i>
                    </div>

                    <div class="input-box">
                        <input type="password" class="input-field" placeholder="Password" name="password" id="password" autocomplete="off" required>
                        <i class="bx bx-lock-alt"></i>
                    </div>
                    <?php
                if (isset($_POST['submit'])) {
                    include("php/config.php");
                    $email = mysqli_real_escape_string($con, $_POST['email']);
                    $password = mysqli_real_escape_string($con, $_POST['password']);

                    $result = mysqli_query($con, "SELECT * FROM users WHERE Email='$email' AND Password='$password' ") or die("Select Error");
                    $row = mysqli_fetch_assoc($result);

                    if (is_array($row) && !empty($row)) {
                        $_SESSION['valid'] = $row['Email'];
                        $_SESSION['username'] = $row['Username'];
                        $_SESSION['age'] = $row['Age'];
                        $_SESSION['id'] = $row['Id'];
                        header("Location: lst.php");
                        exit();
                    } else {
                        echo "<script>document.getElementById('login').scrollIntoView();</script>";
                        echo "<div class='message'>
                                  <p>Wrong Username or Password!</p>
                              </div>";
                    }
                }
                ?>

                    <div class="input-box">
                        <input type="submit" class="submit" name="submit" value="Login" required>
                    </div>
                    <div class="two-col">
                        <div class="one">
                            <input type="checkbox" id="login-check">
                            <label for="login-check"> Remember Me</label>
                        </div>
                        <div class="two">
                            <label><a href="forget_password.php">Forgot password?</a></label>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>