<?php
session_start();

include("php/config.php");
if(!isset($_SESSION['valid'])){
    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Travel Home</title>
<link rel="stylesheet" href="css/lst.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>


<style>
@media screen and (max-width: 768px) {
    .menu-icon {
        display: block;
    }

    .menu-icon.active div:nth-child(1) {
        transform: rotate(45deg) translate(5px, 5px);
    }

    .menu-icon.active div:nth-child(2) {
        opacity: 0;
    }

    .menu-icon.active div:nth-child(3) {
        transform: rotate(-45deg) translate(5px, -5px);
    }

    nav ul {
        display: none;
    }

    nav ul.show {
        display: flex;
        flex-direction: column;
        position: absolute;
        top: 100%;
        left: 0;
        width: 100%;
        background-color: #f8f9fa;
        padding: 20px;
    }

    nav ul li {
        margin: 10px 0;
    }
}
</style>


<body>
<header>
<nav>
<ul>
<li><a href="#">Home</a></li>
<li><a href="blog.html">Forum</a></li>
</ul>
 <div class="user-icon">
                <a href="edit.php"><i class="fas fa-user"></i></a>
            </div>
<div class="right-links">

            <?php 
            
            $id = $_SESSION['id'];
            $query = mysqli_query($con,"SELECT*FROM users WHERE Id=$id");

            while($result = mysqli_fetch_assoc($query)){
                $res_Uname = $result['Username'];
                $res_Email = $result['Email'];
                $res_Age = $result['Age'];
                $res_id = $result['Id'];
            }
            
            $_SESSION['username'] = $res_Uname;
            $_SESSION['email'] = $res_Email;
            ?>

            <a href="php/logout.php"> <button class="btn" style="margin-left:10px;">Log Out</button> </a>

        </div>
</nav>
<div class="menu-icon" onclick="toggleMenu()">
    <div></div>
    <div></div>
    <div></div>
</div>
</header>

<section class="intro">

<h1>Hello <b><?php echo $res_Uname ?></b>, Where to go?</h1>
        <div class="slider">
        <div class="slides">
            <div class="slide"><img src="images/London.jpeg" alt="Image 1"></div>
            <div class="slide"><img src="images/Cusco.jpeg" alt="Image 2"></div>
            <div class="slide"><img src="images/Bali.jpeg" alt="Image 3"></div>
        </div>
    	</div>
        <div class="continent-selector">
            <a href="Asia.php">Asia</a>
            <a href="SA.php">South America</a>
            <a href="NA.php">North America</a>
            <a href="EU.php">Europe</a>
            <a href="Africa.php">Africa</a>
            <a href="Oceania.php">Oceania</a>
        </div>
        <h2>Choose the prefered continent and CLICK THE PINS</h2>
    </section>
    
    <section id="map-container">
        <img src="images/map_child.png" usemap="#worldmap" alt="World Map" class="map-image">
        <div id="NA" class="map-arrow" style="position: absolute; top: 200px; left: 320px; width: 100px; height: 100px; background: url('images/ping.PNG') no-repeat center; background-size: contain;" data-highlight="arrow-africa-highlight.png" data-hover="North America" data-link="NA.php"></div>
     	<div id="SA" class="map-arrow" style="position: absolute; top: 600px; left: 380px; width: 100px; height: 100px; background: url('images/ping.PNG') no-repeat center; background-size: contain;" data-highlight="arrow-africa-highlight.png" data-hover="South America" data-link="SA.php"></div>
    	<div id="ASIA" class="map-arrow" style="position: absolute; top: 200px; left: 1000px; width: 100px; height: 100px; background: url('images/ping.PNG') no-repeat center; background-size: contain;" data-highlight="arrow-africa-highlight.png" data-hover="Asia" data-link="Asia.php"></div>
    	<div id="EU" class="map-arrow" style="position: absolute; top: 270px; left: 680px; width: 100px; height: 100px; background: url('images/ping.PNG') no-repeat center; background-size: contain;" data-highlight="arrow-africa-highlight.png" data-hover="Europe" data-link="EU.php"></div>
     	<div id="AF" class="map-arrow" style="position: absolute; top: 570px; left: 720px; width: 100px; height: 100px; background: url('images/ping.PNG') no-repeat center; background-size: contain;" data-highlight="arrow-africa-highlight.png" data-hover="Africa" data-link="africa.php"></div>
		<div id="OC" class="map-arrow" style="position: absolute; top: 550px; left: 1100px; width: 100px; height: 100px; background: url('images/ping.PNG') no-repeat center; background-size: contain;" data-highlight="arrow-oceania-highlight.png" data-hover="Oceania" data-link="Oceania.php"></div>
 	</section>

 	<div id="tooltip" style="position: absolute; display: none; padding: 10px; background: white; border: 1px solid black;"></div>
 	<div id="tooltip" style="position: absolute; display: none; padding: 10px; background: white; border: 1px solid black;"></div>

	<footer class="footer">
		<div class="footer-left">
            <a href="https://www.visa.cn" target="_blank" class="visa-link">
                <img src="images/lstfooter.png" alt="Visa Payment" class="footer-logo">
                <span>Pay method</span>
            </a>
        </div>
        <div class="footer-middle">
       <p>    Discover the world with Explorer's Path, your ultimate travel companion! At Explorer's Path, we believe every journey should be unforgettable and hassle-free. Our website offers detailed guides, user-friendly tools, and insider tips to help you plan the perfect getaway. Whether you're dreaming of a serene beach vacation, an adventurous mountain trek, or a culturally rich city tour, Explorer's Path has everything you need to turn those dreams into reality.
</p>

        </div>
        <div class="footer-right">
            <p>©2024 Team 05 All rights reserved.</p>
        </div>
        
    </footer>
    <script src="js/lst.js"></script>
    
    
</body>
</html>