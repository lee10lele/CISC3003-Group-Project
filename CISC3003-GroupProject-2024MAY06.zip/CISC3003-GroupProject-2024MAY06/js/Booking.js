const destinationDescriptions = {
    "Great wall": "Embark on an unforgettable adventure in China. Experience the thrill of spotting the Big Five and witness the breathtaking beauty of the Beijing.",
    "Bali": "Discover the enchanting beauty of Bali, Indonesia. Immerse yourself in the vibrant culture, stunning landscapes, and serene beaches of this tropical paradise.",
    "Kyoto Temples": "Explore the ancient temples and shrines of Kyoto, Japan. Step back in time and experience the rich history and spiritual traditions of this captivating city.",
    "Taj Mahal": "Marvel at the iconic Taj Mahal in Agra, India. Be awestruck by the sheer beauty and grandeur of this magnificent monument, a testament to eternal love.",
    "Mombasa": "Embark on a thrilling safari adventure in Mombasa, Kenya. Witness the incredible wildlife, pristine beaches, and vibrant culture of this East African gem.",
    "Timbuktu": "Journey to the legendary city of Timbuktu, Mali. Uncover the rich history, ancient manuscripts, and unique architecture of this UNESCO World Heritage site.",
    "Mafia Island": "Escape to the tranquil shores of Mafia Island, Tanzania. Indulge in world-class diving, snorkeling, and relaxation in this unspoiled tropical paradise.",
    "Marrakech": "Immerse yourself in the vibrant colors, spices, and sounds of Marrakech, Morocco. Explore the bustling markets, ancient palaces, and stunning gardens of this enchanting city.",
    "Eiffel Tower": "Witness the iconic symbol of Paris, France - the Eiffel Tower. Climb to the top for breathtaking views of the city of love and light.",
    "Big Ben": "Stand in awe before the majestic Big Ben in London, England. Admire the intricate clock tower and soak in the rich history of this British landmark.",
    "Sagrada Família": "Marvel at the architectural masterpiece of Sagrada Família in Barcelona, Spain. Discover the stunning details and ongoing construction of this iconic basilica.",
    "Amsterdam Canals": "Cruise along the picturesque canals of Amsterdam, Netherlands. Admire the charming houses, quaint bridges, and vibrant culture of this enchanting city.",
    "Manhattan": "Experience the energy and excitement of Manhattan, New York City. Explore world-renowned attractions, diverse neighborhoods, and the iconic skyline of the Big Apple.",
    "CN Tower": "Ascend to the top of the CN Tower in Toronto, Canada. Enjoy panoramic views of the city and Lake Ontario from this iconic observation tower.",
    "Guanajuato": "Discover the colorful colonial city of Guanajuato, Mexico. Wander through the narrow alleys, visit the underground streets, and immerse yourself in the rich cultural heritage.",
    "ND Basilica": "Visit the stunning Notre-Dame Basilica in Montreal, Canada. Admire the intricate gothic architecture, beautiful stained glass windows, and serene atmosphere of this sacred space.",
    "Bencich Building": "Explore the historic Bencich Building in Buenos Aires, Argentina. Discover the beautiful architecture, rich history, and cultural significance of this iconic landmark.",
    "Christ Redeemer": "Stand in awe before the iconic Christ the Redeemer statue in Rio de Janeiro, Brazil. Marvel at the breathtaking views of the city and the surrounding mountains from this world-famous monument.",
    "Ramoneda Palace": "Step back in time at the Ramoneda Palace in Valencia, Spain. Admire the stunning baroque architecture, lush gardens, and opulent interiors of this historic palace.",
    "Plaza de armas": "Immerse yourself in the vibrant atmosphere of Plaza de Armas in Cusco, Peru. Explore the historic square, admire the colonial architecture, and witness the lively local culture.",
    "Great Barrier Reef": "Dive into the crystal-clear waters of the Great Barrier Reef, Australia. Explore the world's largest coral reef system and discover a vibrant underwater world teeming with colorful marine life and breathtaking coral formations.",
    "Opera House": "Experience the architectural splendor of the Sydney Opera House in Australia. Attend a world-class performance or take a guided tour to learn about the history and cultural significance of this iconic UNESCO World Heritage site.",
    "Milford Sound": "Embark on a journey through the stunning landscapes of Milford Sound in New Zealand. Cruise past majestic waterfalls and towering cliffs in one of the world's most awe-inspiring fjords.",
    "Hobbiton": "Step into the magical world of Hobbiton, the famous movie set from The Lord of the Rings and The Hobbit film series, located in New Zealand. Wander through the enchanting village and discover the hobbit holes that line the rolling hills."
};

const destinationImages = {
    "Great wall": "images/Beijing.jpeg",
    "Bali": "images/Bali.jpeg",
    "Kyoto Temples": "images/Temples and Shrines of Kyoto.jpeg",
    "Taj Mahal": "images/Agra.jpeg",
    "Mombasa": "images/Mombasa.jpeg",
    "Timbuktu": "images/Timbuktu.jpeg",
    "Mafia Island": "images/Mafia Island.jpeg",
    "Marrakech": "images/Marrakech.jpeg",
    "Eiffel Tower": "images/Paris.jpeg",
    "Big Ben": "images/London.jpeg",
    "Sagrada Família": "images/Barcelona.jpeg",
    "Amsterdam Canals": "images/Amsterdam.jpeg",
    "Manhattan": "images/NY.png",
    "CN Tower": "images/canada.jpeg",
    "Guanajuato": "images/Mexico.jpeg",
    "ND Basilica": "images/Montreal.jpeg",
    "Bencich Building": "images/Buenos Aires.jpeg",
    "Christ Redeemer": "images/Brasília.jpeg",
    "Ramoneda Palace": "images/palace.jpeg",
    "Plaza de armas": "images/Cusco.jpeg",
    "Great Barrier Reef": "images/baojiao.jpeg",
    "Opera House": "images/operahouse.jpeg",
    "Milford Sound": "images/Milford.jpeg",
    "Hobbiton": "images/Hobbiton.jpeg"
};

document.querySelector('.booking-form form').addEventListener('submit', function(event) {
    event.preventDefault();

    const tickets = parseInt(document.getElementById('tickets').value);
    const totalPrice = tickets * 18000; 

    document.getElementById('total-price').textContent = 'MOP ' + totalPrice.toFixed(2);
    document.querySelector('.booking-summary').style.display = 'block';
});

document.getElementById('destination').addEventListener('change', function() {
    const destinationName = this.options[this.selectedIndex].text;
    const destinationPrice = this.value;

    document.getElementById('destination-name').textContent = destinationName;
    document.getElementById('destination-image').src = destinationImages[destinationName];
    document.getElementById('destination-description').textContent = destinationDescriptions[destinationName];
    document.getElementById('destination-price').textContent = `Price: MOP ${destinationPrice}`;
});

document.querySelector('.btn').addEventListener('click', function() {
    document.querySelector('.booking-section').style.display = 'block';
});

const paymentMethods = document.querySelectorAll('.payment-icon');
paymentMethods.forEach(method => {
    method.addEventListener('click', function() {
        const paymentMethod = this.getAttribute('data-payment-method');
        let paymentWindow = window.open('', 'Payment', 'width=500,height=600');

        const style = `
            <style>
                body {
                    font-family: Arial, sans-serif;
                    padding: 20px;
                    background-color: #f4f4f9;
                    color: #333;
                }
                h2 {
                    color: #444;
                    margin-bottom: 20px;
                }
                label {
                    display: block;
                    margin: 10px 0 5px;
                }
                input[type="text"], input[type="email"] {
                    width: calc(100% - 22px);
                    padding: 10px;
                    margin-bottom: 20px;
                    border: 1px solid #ccc;
                    border-radius: 4px;
                }
                button {
                    background-color: #5c67f2;
                    color: white;
                    border: none;
                    padding: 10px 20px;
                    cursor: pointer;
                    border-radius: 4px;
                }
                button:hover {
                    background-color: #4a54e1;
                }
            </style>
        `;

        if (paymentMethod === 'paypal') {
            
            paymentWindow.document.write(`
                ${style}
                <h2>PayPal Payment</h2>
                <label for="paypal-email">PayPal Email:</label>
                <input type="email" id="paypal-email" name="paypal-email" required>
                <button onclick="window.close()">Complete Payment</button>
            `);
        } else {
            
            paymentWindow.document.write(`
                ${style}
                <h2>${paymentMethod.toUpperCase()} Payment</h2>
                <label for="card-number">Card Number:</label>
                <input type="text" id="card-number" name="card-number" required>
                <label for="expiry-date">Expiry Date:</label>
                <input type="text" id="expiry-date" name="expiry-date" required>
                <label for="cvv">CVV:</label>
                <input type="text" id="cvv" name="cvv" required>
                <button onclick="window.close()">Complete Payment</button>
            `);
        }
    });
});