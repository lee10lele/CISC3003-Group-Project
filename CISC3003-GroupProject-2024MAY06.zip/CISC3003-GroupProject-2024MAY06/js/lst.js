
document.querySelectorAll('.map-arrow').forEach(arrow => {
    arrow.addEventListener('mouseenter', function(event) {
        const tooltip = document.getElementById('tooltip');
        tooltip.style.display = 'block';
        tooltip.textContent = this.getAttribute('data-hover');  // 显示大洲名
        tooltip.style.left = (event.pageX + 10) + 'px';  // 稍微偏移，防止挡住鼠标
        tooltip.style.top = (event.pageY + 10) + 'px';
    });

    arrow.addEventListener('mouseleave', function() {
        const tooltip = document.getElementById('tooltip');
        tooltip.style.display = 'none';
    });
});

document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.map-arrow').forEach(function(arrow) {
        arrow.addEventListener('click', function() {
            var link = this.getAttribute('data-link');
            window.location.href = link; // 导航到指定的链接
        });
    });
});

document.addEventListener('DOMContentLoaded', function() {
    let currentIndex = 0; // 当前显示的幻灯片索引
    const slides = document.querySelectorAll('.slide');
    const totalSlides = slides.length;

    // 初始化第一张幻灯片为可见状态
    slides[currentIndex].style.opacity = 1;

    function showNextSlide() {
        // 隐藏当前幻灯片
        slides[currentIndex].style.opacity = 0;
        
        // 计算下一张幻灯片的索引
        currentIndex = (currentIndex + 1) % totalSlides;
        
        // 显示下一张幻灯片
        slides[currentIndex].style.opacity = 1;
        
        // 每3秒切换一次幻灯片
        setTimeout(showNextSlide, 1000);
    }

    // 开始轮播
    setTimeout(showNextSlide, 1000);
});