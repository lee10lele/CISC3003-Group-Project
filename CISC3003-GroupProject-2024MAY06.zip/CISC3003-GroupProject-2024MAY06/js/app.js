function getRepresentativeReview(reviews) {
  const averageRating = reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length;
  let representativeReview = reviews[0];
  let minDifference = Math.abs(reviews[0].rating - averageRating);

  for (let i = 1; i < reviews.length; i++) {
    const difference = Math.abs(reviews[i].rating - averageRating);
    if (difference < minDifference) {
      minDifference = difference;
      representativeReview = reviews[i];
    }
  }

  return `${representativeReview.user} (Rating: ${representativeReview.rating}): ${representativeReview.comment}`;
}

function displayAttractions(continent) {
  const attractionList = document.getElementById('attraction-list');
  attractionList.innerHTML = '';

  const continentTitle = document.getElementById('continent-title');
  continentTitle.textContent = continent === 'all' ? 'Welcome to the Attraction Rating Website!' : `Attractions in ${continent}`;

  const filteredAttractions = continent === 'all' ? data : data.filter(attraction => attraction.continent === continent);

  filteredAttractions.forEach(attraction => {
    const averageRating = attraction.reviews.reduce((sum, review) => sum + review.rating, 0) / attraction.reviews.length;
    
    const attractionElement = document.createElement('div');
    attractionElement.classList.add('attraction');
    attractionElement.innerHTML = `
  <div class="attraction-details">
    <h2>${attraction.name}</h2>
    <p>${attraction.description}</p>
    <p>City: ${attraction.city}</p>
    <p>Rating: ${averageRating.toFixed(1)}</p>
    <div class="reviews">
      <h3>Reviews:</h3>
      <p>${getRepresentativeReview(attraction.reviews)}</p>
      <button class="show-more-btn">Show More Reviews</button>
    </div>
    <a href="${attraction.bookingUrl}" target="_blank" class="booking-btn">Book Now</a>
  </div>
  <img src="${attraction.imageUrl}" alt="${attraction.name}">
`;
    attractionList.appendChild(attractionElement);

    const showMoreBtn = attractionElement.querySelector('.show-more-btn');
    showMoreBtn.addEventListener('click', () => {
      const reviewsElement = attractionElement.querySelector('.reviews');
      reviewsElement.innerHTML = `
        <h3>Reviews:</h3>
        ${attraction.reviews.map(review => `
          <p>${review.user} (Rating: ${review.rating}): ${review.comment}</p>
        `).join('')}
      `;
    });
  });
}

fetch('./attractions.json')
  .then(response => response.json())
  .then(data => {
    window.data = data; // Store the data in a global variable

    displayAttractions('all');

    const continentLinks = document.querySelectorAll('.continent-link');
    continentLinks.forEach(link => {
      link.addEventListener('click', (event) => {
        event.preventDefault();
        const continent = link.getAttribute('data-continent');
        displayAttractions(continent);
      });
    });
  })
  .catch(error => {
    console.error('Error loading attraction data:', error);
  });
  
  
const modal = document.getElementById('review-modal');
const openModalBtn = document.getElementById('open-modal-btn');
const closeModalBtn = document.getElementsByClassName('close')[0];

openModalBtn.onclick = function() {
  modal.style.display = 'block';
}

closeModalBtn.onclick = function() {
  modal.style.display = 'none';
}

window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = 'none';
  }
}

const reviewForm = document.querySelector('.review-form');

reviewForm.addEventListener('submit', (event) => {
  event.preventDefault();

  const spot = document.getElementById('spot').value;
  const username = document.getElementById('username').value;
  const rating = parseFloat(document.getElementById('rating').value);
  const comment = document.getElementById('comment').value;

  const newReview = {
    user: username,
    rating: rating,
    comment: comment
  };

  const attraction = data.find(attraction => attraction.name === spot);
  if (attraction) {
    attraction.reviews.push(newReview);
    displayAttractions('all');
  }

  modal.style.display = 'none';
  reviewForm.reset();
});