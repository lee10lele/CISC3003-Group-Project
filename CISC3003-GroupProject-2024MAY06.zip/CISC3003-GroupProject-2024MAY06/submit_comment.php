<?php
$conn = new mysqli('localhost', 'root', '', 'forum');

if ($conn->connect_error) {
    die("ERROR:" . $conn->connect_error);
}

$name = $_POST['name'];
$email = $_POST['email'];
$comment = $_POST['comment'];
$blog_id = $_POST['blog_id'];

$comment_time = date('Y-m-d H:i:s');

$sql = "SELECT comment_name, comment_time, comment_email, comment FROM detail WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $blog_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $existing_names = $row['comment_name'];
    $existing_times = $row['comment_time'];
    $existing_emails = $row['comment_email'];
    $existing_comments = $row['comment'];

    if (!empty($existing_comments)) {
        $updated_names = $existing_names . ';' . $name;
        $updated_times = $existing_times . ';' . $comment_time;
        $updated_emails = $existing_emails . ';' . $email;
        $updated_comments = $existing_comments . ';' . $comment;
    } else {
        $updated_names = $name;
        $updated_times = $comment_time;
        $updated_emails = $email;
        $updated_comments = $comment;
    }

    $sql = "UPDATE detail SET comment_name=?, comment_time=?, comment_email=?, comment=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssi", $updated_names, $updated_times, $updated_emails, $updated_comments, $blog_id);
} else {
    $sql = "INSERT INTO detail (comment_name, comment_time, comment_email, comment, id) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssi", $name, $comment_time, $email, $comment, $blog_id);
}

if ($stmt->execute()) {
    header("Location: blog-details.php?id=$blog_id");
    exit();
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>