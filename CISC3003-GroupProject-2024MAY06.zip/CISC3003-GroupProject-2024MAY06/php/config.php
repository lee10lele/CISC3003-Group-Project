<?php 
 
 $con = mysqli_connect("localhost", "root", "", "tutorial", 3306) or die("Couldn't connect");

?>