<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Explore The World</title>
<link rel="stylesheet" href="css/NorthAmerica.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<style>
    img:hover {
        opacity: 0.7; /* 设置悬停时的透明度 */
        transition: opacity 0.3s ease-in-out; /* 平滑的过渡效果 */
    }
</style>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        // 获取所有图片元素
        var images = document.querySelectorAll('img');
        images.forEach(function(img) {
            img.addEventListener('mouseover', function() {
                img.style.opacity = '0.7';
            });
            img.addEventListener('mouseout', function() {
                img.style.opacity = '1.0';
            });
        });
    });
</script>
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="lst.php">Home</a></li>
                <li><a href="blog.html">Forum</a></li>                  
            </ul>
            <div class="user-icon">
                <a href="edit.php"><i class="fas fa-user"></i></a>
            </div>
        </nav>
    </header>
    <section class="intro">
        <h1>Explore The World</h1>
        <p>Discover different regions and learn about their cultures.</p>
    </section>
    
    <div class="HoneymoonDesti">
        <div class="container">
            <div class="row">
                <div>
                    <h1>Oceania Tourism</h1>
                    <p>Oceania offers a rich tapestry of cultures, stunning landscapes, and diverse ecosystems, making it a unique destination for travelers seeking adventure and relaxation alike. From the iconic Sydney Opera House in Australia to the pristine beaches of Fiji, the region provides endless opportunities for exploration and enjoyment.</p>
                </div>
                
                <div class="container">
                    <div class="row">
                        <div class="col-sm-3">
                            <h3>Great Barrier Reef</h3>
                            <a href="Rating.html"><img src="img/baojiao.jpeg" alt="Great Barrier Reef"></a>
                            <span>Australia International customized tour package</span><hr>
                            <span>MOP 19,000</span>
                        </div>
                        <div class="col-sm-3">
                            <h3>Opera House</h3>
                            <a href="Rating.html"><img src="img/operahouse.jpeg" alt="Opera House"></a>
                            <span>Australia International customized tour package</span><hr>
                            <span>MOP 17,000</span>
                        </div>
                        <div class="col-sm-3">
                            <h3>Milford Sound</h3>
                            <a href="Rating.html"><img src="img/Milford.jpeg" alt="Milford Sound"></a>
                            <span>New Zealand International customized tour package</span><hr>
                            <span>MOP 15,000</span>
                        </div>
                        <div class="col-sm-3">
                            <h3>Hobbiton</h3>
                            <a href="Rating.html"><img src="img/Hobbiton.jpeg" alt="Hobbiton"></a>
                            <span>New Zealand International customized tour package</span><hr>
                            <span>MOP 19,000</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
   <footer class="footer">
  <div class="footer-left">
            <a href="https://www.visa.com" target="_blank" class="visa-link">
                <img src="images/lstfooter.png" alt="Visa Payment" class="footer-logo">
                <span>Pay method</span>
            </a >
        </div>
        <div class="footer-middle">
       <p>    Discover the world with Explorer's Path, your ultimate travel companion! At Explorer's Path, we believe every journey should be unforgettable and hassle-free. Our website offers detailed guides, user-friendly tools, and insider tips to help you plan the perfect getaway. Whether you're dreaming of a serene beach vacation, an adventurous mountain trek, or a culturally rich city tour, Explorer's Path has everything you need to turn those dreams into reality.
</p>

        </div>
        <div class="footer-right">
            <p>©2024 Team 05 All rights reserved.</p>
        </div>
        
    </footer>
</body>
</html>