﻿<!DOCTYPE html>
<html lang="en">
<head>
	<title>Forum - details</title>

  <!-- Theme CSS -->
	<link id="style-switch" rel="stylesheet" type="text/css" href="css/wh.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">

<style>
header {
    background-color: #eaeaea;
    padding: 10px 0;
    width: 100%;
    box-sizing: border-box;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 1000;
    margin-bottom: 10px;
}

header nav ul {
    display: flex;
    justify-content: space-between; /* 确保列表项分散对齐 */
    list-style: none; /* 移除列表项目的默认样式 */
    margin: 0;
    padding: 0;
}

header nav ul li {
    padding: 10px; /* 或者你需要的任何值 */
}

/* 针对图标的特定样式 */
.user-icon {
    margin-left: 800px; /* 把用户图标推到右侧 */
}

.user-icon a {
    display: flex; /* 使得 Font Awesome 图标垂直居中 */
    align-items: center; /* 使得 Font Awesome 图标垂直居中 */
    justify-content: center; /* 使得 Font Awesome 图标水平居中 */
}

.user-icon a i {
    font-size: 24px; /* 或者你需要的图标大小 */
}

nav {
    display: flex;  /* 设置为Flexbox布局 */
    justify-content: center;  /* 沿主轴居中 */
    align-items: center;  /* 沿交叉轴居中 */
    height: 100%;  /* 设置高度为100% */
    width: 100%;  /* 设置宽度为100% */
}

nav ul {
    list-style: none;
    padding: 0;
    margin: 0;
    display: flex;
    justify-content: center;  /* 内部列表项水平居中 */
    align-items: center;  /* 内部列表项垂直居中 */
}

nav ul li {
    margin: 0 20px;
}

nav ul li a {
    text-decoration: none;
    color: #333;
    font-weight: bold;
}

nav ul li a:hover {
    color: #007bff;
}

</style>

</head>
    <header>
        <nav>
            <ul>
            	<li><a href="lst.php">Home</a></li>
                <li><a href="blog.html">Forum</a></li>                  
            </ul>
            <div class="user-icon">
                <a href="edit.php"><i class="fas fa-user"></i></a>
            </div>
        </nav>
       </header>

<body>

<?php 
session_start(); 

if (isset($_SESSION['username']) && isset($_SESSION['email'])) {
    $username = $_SESSION['username'];
    $email = $_SESSION['email'];
}
?>
<?php

$conn = new mysqli('localhost', 'root', '', 'forum');


if ($conn->connect_error) {
    die("ERROR:" . $conn->connect_error);
}


$blog_id = $_GET['id'];


$sql = "SELECT tag, title, content, comment_name, comment_time, comment FROM detail WHERE id = $blog_id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $blog = $result->fetch_assoc();
    $tag = $blog['tag'];
    $title = $blog['title'];
	$content = $blog['content'];

    $comment_data = array();

    if (!empty($blog['comment_name']) && !empty($blog['comment_time']) && !empty($blog['comment'])) {
        $comment_names = explode(';', $blog['comment_name']);
        $comment_times = explode(';', $blog['comment_time']);
        $comments = explode(';', $blog['comment']);

        foreach ($comments as $index => $comment) {
            $comment_data[] = array(
                'name' => isset($comment_names[$index]) ? $comment_names[$index] : '',
                'time' => isset($comment_times[$index]) ? $comment_times[$index] : '',
                'comment' => $comment
            );
        }
    }
} else {
    echo "404 NO FOUND";
    exit();
}

$conn->close();
?>

<!-- **************** MAIN CONTENT START **************** -->
<main>
  
  <!-- Container START -->
  <div class="container">
    <div class="row g-4">
      <!-- Main content START -->
      <div class="col-lg-8 mx-auto">
        <div class="vstack gap-4">
          <!-- Blog single START -->
			<div class="card card-body">
    			<img class="rounded" src="images/<?php echo $blog_id; ?>.jpg" alt="">
    			<div class="mt-4">
        		<!-- Tag -->
        		<a href="#" class="badge bg-danger bg-opacity-10 text-danger mb-2 fw-bold"><?php echo $tag; ?></a>
        		<!-- Title info -->
        		<h1 class="mb-2 h2"><?php echo $title; ?></h1>
        		<ul class="nav nav-stack gap-3 align-items-center">
            		<li class="nav-item">
                		<div class="nav-link">
                    		by <a href="#" class="text-reset btn-link">Team 05</a>
                		</div>
            		</li>
            		<li class="nav-item"> <i class="bi bi-calendar-date pe-1"></i>APR 22, 2024</li>
        		</ul>
        		<!-- description -->
        		<p class="mt-4"><?php echo $content; ?></p>
    			</div>
			</div>
          <!-- Card END -->
          <!-- Comments START -->
          <div class="card">
            <div class="card-header pb-0 border-0">
              <h4>Comments</h4>
            </div>
            <div class="card-body">      
<!-- Comments START -->
<?php
if (!empty($comment_data)) {
    foreach ($comment_data as $comment) {
        ?>
        <div class="my-4 d-flex">
            <img class="avatar avatar-md rounded-circle float-start me-3" src="images/user.png" alt="avatar">
            <div>
                <div class="mb-2 d-sm-flex">
                    <h6 class="m-0 me-2"><?php echo $comment['name']; ?></h6>
                    <span class="me-3 small"><?php echo $comment['time']; ?></span>
                </div>
                <p><?php echo $comment['comment']; ?></p>
            </div>
        </div>
        <?php
    }
} else {
    echo "No comments yet.";
}
?>
<!-- Comments END -->
              <hr class="my-4">
              <!-- Reply START -->
              <div>
  <h4>Leave a reply</h4>
  <form class="row g-3 mt-2" action="submit_comment.php" method="post">
    <!-- Name -->
	<div class="col-md-6">
  		<label class="form-label">Name *</label>
  		<input type="text" class="form-control" name="name" value="<?php echo $username; ?>" required>
	</div>
    <!-- Email -->
	<div class="col-md-6">
  		<label class="form-label">Email *</label>
  		<input type="email" class="form-control" name="email" value="<?php echo $email; ?>" required>
	</div>
    <!-- Your Comment -->
    <div class="col-12">
      <label class="form-label">Your Comment *</label>
      <textarea class="form-control" rows="3" name="comment" required></textarea>
    </div>
    <!-- Hidden input for blog ID -->
    <input type="hidden" name="blog_id" value="<?php echo $blog_id; ?>">
    <!-- Button -->
    <div class="col-12">
      <button type="submit" class="btn btn-primary">Post comment</button>
    </div>
  </form>
</div>
              <!-- Reply END -->
            </div>
          </div>
          <!-- Blog single END -->
        </div>
      </div>
      <!-- Main content END -->
    </div> <!-- Row END -->
  </div>
  <!-- Container END -->

</main>

<!-- **************** MAIN CONTENT END **************** -->



 
</body>
</html>